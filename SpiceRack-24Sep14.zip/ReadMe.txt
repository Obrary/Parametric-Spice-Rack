Product: Parametric Spice Rack, September 2014

Designer: 

Support:  http://forums.obrary.com/category/designs/parametric-spice-rack

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Parametric Spice Rack is designed to be cut on a Laser Cutter from 1/4" plywood.
